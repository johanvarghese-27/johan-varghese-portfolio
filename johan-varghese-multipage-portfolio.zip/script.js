// Update the copyright year automatically.
const yearElement = document.getElementById("year");
if (yearElement) yearElement.textContent = new Date().getFullYear();
