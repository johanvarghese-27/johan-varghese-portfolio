JOHAN VARGHESE — MULTI-PAGE PORTFOLIO WEBSITE

Files:
- index.html       Home page (includes profile photo)
- about.html       About me
- skills.html      Technical and personal skills
- education.html   Education
- projects.html    Project details
- achievements.html Achievements, activities, events and languages
- contact.html     Contact information
- styles.css       Shared website styling and responsive layout
- script.js        Small JavaScript enhancement
- profile.png      Your profile photo

HOW TO TEST:
1. Keep all files in the same folder.
2. Open index.html in a web browser.
3. Use the navigation links to move between pages.

HOW TO PUBLISH ON GITHUB PAGES:
1. Open your repository:
   https://github.com/johanvarghese-27/johan-varghese-portfolio
2. Upload ALL files in this folder to the repository root.
3. Make sure profile.png is uploaded alongside index.html.
4. Commit changes.
5. In Settings > Pages, choose Deploy from a branch, branch main,
   folder /(root), and Save.
6. Website:
   https://johanvarghese-27.github.io/johan-varghese-portfolio/

NOTE:
Your photo must be named exactly profile.png. The LinkedIn URL is
not filled in because the actual profile URL was not supplied.
Contact details are included from your resume; remove them if you
prefer not to publish personal contact information publicly.
